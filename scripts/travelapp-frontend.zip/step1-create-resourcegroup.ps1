az group create --name $global:RESOURCE_GROUP --location $global:LOCATION
