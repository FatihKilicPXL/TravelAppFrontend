npm install
npm run build
