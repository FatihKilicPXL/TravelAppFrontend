$global:RESOURCE_GROUP="rg-softengPE-frontend"
$global:LOCATION="francecentral"
$global:SLNDIR=".."